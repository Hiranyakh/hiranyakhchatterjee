"use client";

import { motion } from "framer-motion";

interface CompassBezelProps {
  children?: React.ReactNode;
}

export default function CompassBezel({
  children,
}: CompassBezelProps) {
  return (
    <motion.div
      animate={{ rotate: 360 }}
      transition={{
        duration: 180,
        repeat: Infinity,
        ease: "linear",
      }}
      className="relative flex h-[540px] w-[540px] items-center justify-center rounded-full"
    >
      {/* Metallic Outer Ring */}
      <div
        className="
          absolute inset-0 rounded-full
          bg-[linear-gradient(135deg,#8B6914_0%,#D4AF37_20%,#FFF3C4_50%,#D4AF37_80%,#8B6914_100%)]
          p-[10px]
          shadow-[0_0_60px_rgba(212,175,55,0.25)]
        "
      >
        <div className="h-full w-full rounded-full bg-[#0F172A]" />
      </div>

      {/* Engraved Ring */}
      <div className="absolute inset-[18px] rounded-full border border-[#F6E6A7]/30" />

      {/* Minute Ring */}
      <div className="absolute inset-[36px] rounded-full border border-[#D4AF37]/20" />

      {/* Geometry goes here */}
      {children}
    </motion.div>
  );
}