"use client";

const labels = [
  {
    title: "Health",
    top: "6%",
    left: "50%",
  },
  {
    title: "Wealth",
    top: "30%",
    left: "92%",
  },
  {
    title: "Growth",
    top: "78%",
    left: "86%",
  },
  {
    title: "Purpose",
    top: "94%",
    left: "50%",
  },
  {
    title: "Leadership",
    top: "78%",
    left: "10%",
  },
];

export default function CompassLabels() {
  return (
    <>
      {labels.map((label) => (
        <div
          key={label.title}
          className="
          absolute
          -translate-x-1/2
          -translate-y-1/2
          "
          style={{
            top: label.top,
            left: label.left,
          }}
        >
          <div
            className="
            rounded-full
            bg-[#0F172A]
            px-5
            py-2
            text-white
            font-semibold
            shadow-xl
            "
          >
            {label.title}
          </div>
        </div>
      ))}
    </>
  );
}