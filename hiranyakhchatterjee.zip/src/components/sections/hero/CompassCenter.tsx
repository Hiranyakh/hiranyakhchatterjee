"use client";

interface Props {
  image: string;
}

export default function CompassCenter({
  image,
}: Props) {
  return (
    <div
      className="
      absolute
      w-[220px]
      h-[220px]
      rounded-full
      overflow-hidden
      border-[6px]
      border-white
      shadow-2xl
      bg-white
      "
    >
      <img
        src={image}
        alt="Profile"
        className="w-full h-full object-cover"
      />
    </div>
  );
}