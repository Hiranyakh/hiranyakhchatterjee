"use client";

export default function CompassGeometry() {
  return (
    <svg
      viewBox="0 0 500 500"
      className="absolute inset-0 h-full w-full"
    >
      {/* Outer Geometry Ring */}

      <circle
        cx="250"
        cy="250"
        r="175"
        fill="none"
        stroke="rgba(212,175,55,.25)"
        strokeWidth="1.2"
      />

      <circle
        cx="250"
        cy="250"
        r="145"
        fill="none"
        stroke="rgba(212,175,55,.20)"
        strokeWidth="1"
      />

      <circle
        cx="250"
        cy="250"
        r="115"
        fill="none"
        stroke="rgba(212,175,55,.18)"
        strokeWidth="1"
      />

      {/* Vertical */}

      <line
        x1="250"
        y1="75"
        x2="250"
        y2="425"
        stroke="rgba(212,175,55,.28)"
        strokeWidth="1"
      />

      {/* Horizontal */}

      <line
        x1="75"
        y1="250"
        x2="425"
        y2="250"
        stroke="rgba(212,175,55,.28)"
        strokeWidth="1"
      />

      {/* Diagonal */}

      <line
        x1="125"
        y1="125"
        x2="375"
        y2="375"
        stroke="rgba(212,175,55,.18)"
        strokeWidth="1"
      />

      <line
        x1="375"
        y1="125"
        x2="125"
        y2="375"
        stroke="rgba(212,175,55,.18)"
        strokeWidth="1"
      />

      {/* Center Hub */}

      <circle
        cx="250"
        cy="250"
        r="8"
        fill="#D4AF37"
      />

      <circle
        cx="250"
        cy="250"
        r="18"
        fill="none"
        stroke="rgba(212,175,55,.35)"
      />
    </svg>
  );
}