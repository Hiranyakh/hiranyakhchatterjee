"use client";

import CompassBezel from "./CompassBezel";
import CompassGeometry from "./CompassGeometry";
import CompassNeedle from "./CompassNeedle";

export default function FreedomCompass() {
  return (
    <div className="relative flex items-center justify-center w-[700px] h-[700px]">

      {/* Ambient Glow */}

      <div className="absolute w-[500px] h-[500px] rounded-full bg-[#D4AF37]/10 blur-[120px]" />

      {/* Compass */}

      <CompassBezel>

        <CompassGeometry />

        <CompassNeedle />

      </CompassBezel>

    </div>
  );
}