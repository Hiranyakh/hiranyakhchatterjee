import FreedomCompass from "@/components/freedom-score/hero/FreedomCompass";

export default function CompassLabPage() {
  return (
    <main className="min-h-screen bg-[#081018] flex items-center justify-center">

      <FreedomCompass />

    </main>
  );
}